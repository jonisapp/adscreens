var require = meteorInstall({"imports":{"api":{"images.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/api/images.js                                                            //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.exportDefault(Images = new FS.Collection("images", {
  filter: {
    maxSize: 26214400,
    allow: {
      contentTypes: ['image/*']
    }
  },
  stores: [new FS.Store.FileSystem("images", {
    path: "~/uploads"
  })]
}));
//////////////////////////////////////////////////////////////////////////////////////

},"screens.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/api/screens.js                                                           //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.exportDefault(Screens = new Mongo.Collection('screens'));
//////////////////////////////////////////////////////////////////////////////////////

}},"shared":{"methods.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/shared/methods.js                                                        //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ip;
module.link("ip", {
  default(v) {
    ip = v;
  }

}, 1);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 2);
const adminPassword = 'visuconcept';
const userPasswordFilePath = '/home/visuconcept/password.txt';
Meteor.methods({
  'ip_get': () => {
    return ip.address();
  },
  'screen_updateImage': (screen_id, image_id, image_url) => {
    Meteor.call('screen_reset', screen_id);
    Screens.update({
      _id: screen_id
    }, {
      $set: {
        imageId: image_id,
        imageUrl: image_url,
        enabled: true
      }
    });
  },
  'screen_toggleEnabled': (screen_id, enabled) => {
    Screens.update({
      _id: screen_id
    }, {
      $set: {
        enabled: !enabled
      }
    });
  },
  'screen_updateName': (screen_id, name) => {
    Screens.update({
      _id: screen_id
    }, {
      $set: {
        name
      }
    });
  },
  'screen_toggleFillAndStretch': (screen_id, fill, stretch) => {
    if (fill === !stretch) {
      Screens.update({
        _id: screen_id
      }, {
        $set: {
          backgroundStretch: !stretch,
          fillScreen: !fill
        }
      });
    }
  },
  'screen_updateFill': (screen_id, fill, stretch) => {
    if (stretch) {
      Meteor.call('screen_toggleFillAndStretch', screen_id, fill, stretch);
    }

    Screens.update({
      _id: screen_id
    }, {
      $set: {
        fillScreen: !fill
      }
    });
  },
  'screen_updateStretch': (screen_id, fill, stretch) => {
    if (fill) {
      Meteor.call('screen_toggleFillAndStretch', screen_id, fill, stretch);
    }

    Screens.update({
      _id: screen_id
    }, {
      $set: {
        backgroundStretch: !stretch
      }
    });
  },
  'screen_updateZoom': (screen_id, value) => {
    Screens.update({
      _id: screen_id
    }, {
      $set: {
        backgroundSizePercent: value
      }
    });
  },
  'screen_updateHorizontalPosition': (screen_id, value, vertical_value, reset) => {
    if (reset) {
      value = 50;
      vertical_value = 50;
    }

    Screens.update({
      _id: screen_id
    }, {
      $set: {
        backgroundPositionHorizontal: value,
        backgroundPosition: "".concat(value, "% ").concat(vertical_value, "%")
      }
    });
  },
  'screen_updateVerticalPosition': (screen_id, value, horizontal_value, reset) => {
    if (reset) {
      value = 50;
      horizontal_value = 50;
    }

    Screens.update({
      _id: screen_id
    }, {
      $set: {
        backgroundPositionVertical: value,
        backgroundPosition: "".concat(horizontal_value, "% ").concat(value, "%")
      }
    });
  },
  'screen_reset': screen_id => {
    Screens.update({
      _id: screen_id
    }, {
      $set: {
        backgroundPosition: '50% 50%',
        backgroundPositionVertical: 50,
        backgroundPositionHorizontal: 50,
        backgroundSizePercent: 100,
        backgroundStretch: false,
        fillScreen: false
      }
    });
  },
  'image_remove': (imageId, imageUrl) => {
    Screens.update({
      imageUrl: imageUrl
    }, {
      $set: {
        imageUrl: null,
        enabled: false,
        backgroundSizePercent: 100,
        backgroundPositionHorizontal: 50,
        backgroundPositionVertical: 50,
        backgroundPosition: '50% 50%',
        backgroundStretch: false,
        fillScreen: false,
        backgroundSize: 'contain'
      }
    }, {
      multi: true
    });
    Images.remove({
      _id: imageId
    });
  },
  'check_password': password => {
    const userPassword = fs.readFileSync(userPasswordFilePath, {
      encoding: 'utf8'
    });

    if (password === adminPassword || password === userPassword) {
      return true;
    } else {
      return false;
    }
  },
  'change_password': (oldPassword, newPassword) => {
    const userPassword = fs.readFileSync(userPasswordFilePath, {
      encoding: 'utf8'
    });

    if (oldPassword === adminPassword || oldPassword === userPassword) {
      fs.writeFileSync(userPasswordFilePath, newPassword, 'utf8');
      return true;
    }

    return false;
  }
});
//////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// server/main.js                                                                   //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Images;
module.link("../imports/api/images", {
  default(v) {
    Images = v;
  }

}, 1);
let Screens;
module.link("../imports/api/screens", {
  default(v) {
    Screens = v;
  }

}, 2);
module.link("../imports/shared/methods");
Images.allow({
  insert: () => true,
  update: () => true,
  remove: () => false,
  download: () => true
});
Meteor.publish('images', function () {
  return Images.find({});
});
Meteor.publish('screens', function () {
  return Screens.find({});
});
Meteor.publish('screen_image', function (screenIndex) {
  const screenCursor = Screens.find({
    screenIndex: parseInt(screenIndex)
  });
  const screen = screenCursor.fetch()[0];
  const imageCursor = Images.find({
    _id: screen.imageId
  });
  return [screenCursor, imageCursor];
});
Meteor.startup(() => {});
//////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW1hZ2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zY3JlZW5zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NoYXJlZC9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnREZWZhdWx0IiwiSW1hZ2VzIiwiRlMiLCJDb2xsZWN0aW9uIiwiZmlsdGVyIiwibWF4U2l6ZSIsImFsbG93IiwiY29udGVudFR5cGVzIiwic3RvcmVzIiwiU3RvcmUiLCJGaWxlU3lzdGVtIiwicGF0aCIsIlNjcmVlbnMiLCJNb25nbyIsIk1ldGVvciIsImxpbmsiLCJ2IiwiaXAiLCJkZWZhdWx0IiwiZnMiLCJhZG1pblBhc3N3b3JkIiwidXNlclBhc3N3b3JkRmlsZVBhdGgiLCJtZXRob2RzIiwiYWRkcmVzcyIsInNjcmVlbl9pZCIsImltYWdlX2lkIiwiaW1hZ2VfdXJsIiwiY2FsbCIsInVwZGF0ZSIsIl9pZCIsIiRzZXQiLCJpbWFnZUlkIiwiaW1hZ2VVcmwiLCJlbmFibGVkIiwibmFtZSIsImZpbGwiLCJzdHJldGNoIiwiYmFja2dyb3VuZFN0cmV0Y2giLCJmaWxsU2NyZWVuIiwidmFsdWUiLCJiYWNrZ3JvdW5kU2l6ZVBlcmNlbnQiLCJ2ZXJ0aWNhbF92YWx1ZSIsInJlc2V0IiwiYmFja2dyb3VuZFBvc2l0aW9uSG9yaXpvbnRhbCIsImJhY2tncm91bmRQb3NpdGlvbiIsImhvcml6b250YWxfdmFsdWUiLCJiYWNrZ3JvdW5kUG9zaXRpb25WZXJ0aWNhbCIsImJhY2tncm91bmRTaXplIiwibXVsdGkiLCJyZW1vdmUiLCJwYXNzd29yZCIsInVzZXJQYXNzd29yZCIsInJlYWRGaWxlU3luYyIsImVuY29kaW5nIiwib2xkUGFzc3dvcmQiLCJuZXdQYXNzd29yZCIsIndyaXRlRmlsZVN5bmMiLCJpbnNlcnQiLCJkb3dubG9hZCIsInB1Ymxpc2giLCJmaW5kIiwic2NyZWVuSW5kZXgiLCJzY3JlZW5DdXJzb3IiLCJwYXJzZUludCIsInNjcmVlbiIsImZldGNoIiwiaW1hZ2VDdXJzb3IiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLGFBQVAsQ0FBZUMsTUFBTSxHQUFHLElBQUlDLEVBQUUsQ0FBQ0MsVUFBUCxDQUFrQixRQUFsQixFQUE0QjtBQUNsREMsUUFBTSxFQUFFO0FBQ05DLFdBQU8sRUFBRSxRQURIO0FBRU5DLFNBQUssRUFBRTtBQUNMQyxrQkFBWSxFQUFFLENBQUMsU0FBRDtBQURUO0FBRkQsR0FEMEM7QUFPbERDLFFBQU0sRUFBRSxDQUFDLElBQUlOLEVBQUUsQ0FBQ08sS0FBSCxDQUFTQyxVQUFiLENBQXdCLFFBQXhCLEVBQWtDO0FBQUNDLFFBQUksRUFBRTtBQUFQLEdBQWxDLENBQUQ7QUFQMEMsQ0FBNUIsQ0FBeEIsRTs7Ozs7Ozs7Ozs7QUNBQVosTUFBTSxDQUFDQyxhQUFQLENBQWVZLE9BQU8sR0FBRyxJQUFJQyxLQUFLLENBQUNWLFVBQVYsQ0FBcUIsU0FBckIsQ0FBekIsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJVyxNQUFKO0FBQVdmLE1BQU0sQ0FBQ2dCLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxFQUFKO0FBQU9sQixNQUFNLENBQUNnQixJQUFQLENBQVksSUFBWixFQUFpQjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDQyxNQUFFLEdBQUNELENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7QUFBdUMsSUFBSUcsRUFBSjtBQUFPcEIsTUFBTSxDQUFDZ0IsSUFBUCxDQUFZLElBQVosRUFBaUI7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0csTUFBRSxHQUFDSCxDQUFIO0FBQUs7O0FBQWpCLENBQWpCLEVBQW9DLENBQXBDO0FBS3JILE1BQU1JLGFBQWEsR0FBRyxhQUF0QjtBQUNBLE1BQU1DLG9CQUFvQixHQUFHLGdDQUE3QjtBQUVBUCxNQUFNLENBQUNRLE9BQVAsQ0FBZTtBQUNiLFlBQVUsTUFBTTtBQUNkLFdBQU9MLEVBQUUsQ0FBQ00sT0FBSCxFQUFQO0FBQ0QsR0FIWTtBQUliLHdCQUFzQixDQUFDQyxTQUFELEVBQVlDLFFBQVosRUFBc0JDLFNBQXRCLEtBQW9DO0FBQ3hEWixVQUFNLENBQUNhLElBQVAsQ0FBWSxjQUFaLEVBQTRCSCxTQUE1QjtBQUNBWixXQUFPLENBQUNnQixNQUFSLENBQWU7QUFBRUMsU0FBRyxFQUFFTDtBQUFQLEtBQWYsRUFBbUM7QUFBRU0sVUFBSSxFQUFFO0FBQUVDLGVBQU8sRUFBRU4sUUFBWDtBQUFxQk8sZ0JBQVEsRUFBRU4sU0FBL0I7QUFBMENPLGVBQU8sRUFBRTtBQUFuRDtBQUFSLEtBQW5DO0FBQ0QsR0FQWTtBQVFiLDBCQUF3QixDQUFDVCxTQUFELEVBQVlTLE9BQVosS0FBd0I7QUFDOUNyQixXQUFPLENBQUNnQixNQUFSLENBQWU7QUFBQ0MsU0FBRyxFQUFFTDtBQUFOLEtBQWYsRUFBaUM7QUFBRU0sVUFBSSxFQUFFO0FBQUVHLGVBQU8sRUFBRSxDQUFDQTtBQUFaO0FBQVIsS0FBakM7QUFDRCxHQVZZO0FBV2IsdUJBQXFCLENBQUNULFNBQUQsRUFBWVUsSUFBWixLQUFxQjtBQUN4Q3RCLFdBQU8sQ0FBQ2dCLE1BQVIsQ0FBZTtBQUFDQyxTQUFHLEVBQUVMO0FBQU4sS0FBZixFQUFpQztBQUFFTSxVQUFJLEVBQUU7QUFBRUk7QUFBRjtBQUFSLEtBQWpDO0FBQ0QsR0FiWTtBQWNiLGlDQUErQixDQUFDVixTQUFELEVBQVlXLElBQVosRUFBa0JDLE9BQWxCLEtBQThCO0FBQzNELFFBQUdELElBQUksS0FBSyxDQUFDQyxPQUFiLEVBQXNCO0FBQ3BCeEIsYUFBTyxDQUFDZ0IsTUFBUixDQUFlO0FBQUVDLFdBQUcsRUFBRUw7QUFBUCxPQUFmLEVBQW1DO0FBQUVNLFlBQUksRUFBRTtBQUFFTywyQkFBaUIsRUFBRSxDQUFDRCxPQUF0QjtBQUErQkUsb0JBQVUsRUFBRSxDQUFDSDtBQUE1QztBQUFSLE9BQW5DO0FBQ0Q7QUFDRixHQWxCWTtBQW1CYix1QkFBcUIsQ0FBQ1gsU0FBRCxFQUFZVyxJQUFaLEVBQWtCQyxPQUFsQixLQUE4QjtBQUNqRCxRQUFHQSxPQUFILEVBQVk7QUFDVnRCLFlBQU0sQ0FBQ2EsSUFBUCxDQUFZLDZCQUFaLEVBQTJDSCxTQUEzQyxFQUFzRFcsSUFBdEQsRUFBNERDLE9BQTVEO0FBQ0Q7O0FBQ0R4QixXQUFPLENBQUNnQixNQUFSLENBQWU7QUFBRUMsU0FBRyxFQUFFTDtBQUFQLEtBQWYsRUFBbUM7QUFBRU0sVUFBSSxFQUFFO0FBQUVRLGtCQUFVLEVBQUUsQ0FBQ0g7QUFBZjtBQUFSLEtBQW5DO0FBQ0QsR0F4Qlk7QUF5QmIsMEJBQXdCLENBQUNYLFNBQUQsRUFBWVcsSUFBWixFQUFrQkMsT0FBbEIsS0FBOEI7QUFDcEQsUUFBR0QsSUFBSCxFQUFTO0FBQ1ByQixZQUFNLENBQUNhLElBQVAsQ0FBWSw2QkFBWixFQUEyQ0gsU0FBM0MsRUFBc0RXLElBQXRELEVBQTREQyxPQUE1RDtBQUNEOztBQUNEeEIsV0FBTyxDQUFDZ0IsTUFBUixDQUFlO0FBQUVDLFNBQUcsRUFBRUw7QUFBUCxLQUFmLEVBQW1DO0FBQUVNLFVBQUksRUFBRTtBQUFFTyx5QkFBaUIsRUFBRSxDQUFDRDtBQUF0QjtBQUFSLEtBQW5DO0FBQ0QsR0E5Qlk7QUErQmIsdUJBQXFCLENBQUNaLFNBQUQsRUFBWWUsS0FBWixLQUFzQjtBQUN6QzNCLFdBQU8sQ0FBQ2dCLE1BQVIsQ0FBZTtBQUFFQyxTQUFHLEVBQUVMO0FBQVAsS0FBZixFQUFtQztBQUFFTSxVQUFJLEVBQUU7QUFBRVUsNkJBQXFCLEVBQUVEO0FBQXpCO0FBQVIsS0FBbkM7QUFDRCxHQWpDWTtBQWtDYixxQ0FBbUMsQ0FBQ2YsU0FBRCxFQUFZZSxLQUFaLEVBQW1CRSxjQUFuQixFQUFtQ0MsS0FBbkMsS0FBNkM7QUFDOUUsUUFBR0EsS0FBSCxFQUFVO0FBQ1JILFdBQUssR0FBRyxFQUFSO0FBQVlFLG9CQUFjLEdBQUcsRUFBakI7QUFDYjs7QUFDRDdCLFdBQU8sQ0FBQ2dCLE1BQVIsQ0FBZTtBQUFDQyxTQUFHLEVBQUVMO0FBQU4sS0FBZixFQUFpQztBQUFFTSxVQUFJLEVBQUU7QUFBRWEsb0NBQTRCLEVBQUVKLEtBQWhDO0FBQXVDSywwQkFBa0IsWUFBTUwsS0FBTixlQUFrQkUsY0FBbEI7QUFBekQ7QUFBUixLQUFqQztBQUNELEdBdkNZO0FBd0NiLG1DQUFpQyxDQUFDakIsU0FBRCxFQUFZZSxLQUFaLEVBQW1CTSxnQkFBbkIsRUFBcUNILEtBQXJDLEtBQStDO0FBQzlFLFFBQUdBLEtBQUgsRUFBVTtBQUNSSCxXQUFLLEdBQUcsRUFBUjtBQUFZTSxzQkFBZ0IsR0FBRyxFQUFuQjtBQUNiOztBQUNEakMsV0FBTyxDQUFDZ0IsTUFBUixDQUFlO0FBQUNDLFNBQUcsRUFBRUw7QUFBTixLQUFmLEVBQWlDO0FBQUVNLFVBQUksRUFBRTtBQUFFZ0Isa0NBQTBCLEVBQUVQLEtBQTlCO0FBQXFDSywwQkFBa0IsWUFBTUMsZ0JBQU4sZUFBNkJOLEtBQTdCO0FBQXZEO0FBQVIsS0FBakM7QUFDRCxHQTdDWTtBQThDYixrQkFBaUJmLFNBQUQsSUFBZTtBQUM3QlosV0FBTyxDQUFDZ0IsTUFBUixDQUFlO0FBQUNDLFNBQUcsRUFBRUw7QUFBTixLQUFmLEVBQWlDO0FBQUVNLFVBQUksRUFBRTtBQUFFYywwQkFBa0IsRUFBRSxTQUF0QjtBQUFpQ0Usa0NBQTBCLEVBQUUsRUFBN0Q7QUFBaUVILG9DQUE0QixFQUFFLEVBQS9GO0FBQW1HSCw2QkFBcUIsRUFBRSxHQUExSDtBQUErSEgseUJBQWlCLEVBQUUsS0FBbEo7QUFBeUpDLGtCQUFVLEVBQUU7QUFBcks7QUFBUixLQUFqQztBQUNELEdBaERZO0FBaURiLGtCQUFnQixDQUFDUCxPQUFELEVBQVVDLFFBQVYsS0FBdUI7QUFDckNwQixXQUFPLENBQUNnQixNQUFSLENBQWU7QUFBQ0ksY0FBUSxFQUFFQTtBQUFYLEtBQWYsRUFBcUM7QUFBRUYsVUFBSSxFQUFFO0FBQzNDRSxnQkFBUSxFQUFFLElBRGlDO0FBRTNDQyxlQUFPLEVBQUUsS0FGa0M7QUFHM0NPLDZCQUFxQixFQUFFLEdBSG9CO0FBSTNDRyxvQ0FBNEIsRUFBRSxFQUphO0FBSzNDRyxrQ0FBMEIsRUFBRSxFQUxlO0FBTTNDRiwwQkFBa0IsRUFBRSxTQU51QjtBQU8zQ1AseUJBQWlCLEVBQUUsS0FQd0I7QUFRM0NDLGtCQUFVLEVBQUUsS0FSK0I7QUFTM0NTLHNCQUFjLEVBQUU7QUFUMkI7QUFBUixLQUFyQyxFQVVFO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBVkY7QUFZQS9DLFVBQU0sQ0FBQ2dELE1BQVAsQ0FBYztBQUFDcEIsU0FBRyxFQUFFRTtBQUFOLEtBQWQ7QUFDRCxHQS9EWTtBQWdFYixvQkFBbUJtQixRQUFELElBQWM7QUFDOUIsVUFBTUMsWUFBWSxHQUFHaEMsRUFBRSxDQUFDaUMsWUFBSCxDQUFnQi9CLG9CQUFoQixFQUFzQztBQUFFZ0MsY0FBUSxFQUFFO0FBQVosS0FBdEMsQ0FBckI7O0FBQ0EsUUFBR0gsUUFBUSxLQUFLOUIsYUFBYixJQUE4QjhCLFFBQVEsS0FBS0MsWUFBOUMsRUFBNEQ7QUFDMUQsYUFBTyxJQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxLQUFQO0FBQ0Q7QUFDRixHQXZFWTtBQXdFYixxQkFBbUIsQ0FBQ0csV0FBRCxFQUFjQyxXQUFkLEtBQThCO0FBQy9DLFVBQU1KLFlBQVksR0FBR2hDLEVBQUUsQ0FBQ2lDLFlBQUgsQ0FBZ0IvQixvQkFBaEIsRUFBc0M7QUFBRWdDLGNBQVEsRUFBRTtBQUFaLEtBQXRDLENBQXJCOztBQUNBLFFBQUdDLFdBQVcsS0FBS2xDLGFBQWhCLElBQWlDa0MsV0FBVyxLQUFLSCxZQUFwRCxFQUFrRTtBQUNoRWhDLFFBQUUsQ0FBQ3FDLGFBQUgsQ0FBaUJuQyxvQkFBakIsRUFBdUNrQyxXQUF2QyxFQUFvRCxNQUFwRDtBQUNBLGFBQU8sSUFBUDtBQUNEOztBQUNELFdBQU8sS0FBUDtBQUNEO0FBL0VZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQSxJQUFJekMsTUFBSjtBQUFXZixNQUFNLENBQUNnQixJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWYsTUFBSjtBQUFXRixNQUFNLENBQUNnQixJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ2YsVUFBTSxHQUFDZSxDQUFQO0FBQVM7O0FBQXJCLENBQXBDLEVBQTJELENBQTNEO0FBQThELElBQUlKLE9BQUo7QUFBWWIsTUFBTSxDQUFDZ0IsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNKLFdBQU8sR0FBQ0ksQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RDtBQUFnRWpCLE1BQU0sQ0FBQ2dCLElBQVAsQ0FBWSwyQkFBWjtBQU9yTmQsTUFBTSxDQUFDSyxLQUFQLENBQWE7QUFDWG1ELFFBQU0sRUFBRSxNQUFNLElBREg7QUFFWDdCLFFBQU0sRUFBRSxNQUFNLElBRkg7QUFHWHFCLFFBQU0sRUFBRSxNQUFNLEtBSEg7QUFJWFMsVUFBUSxFQUFFLE1BQU07QUFKTCxDQUFiO0FBT0E1QyxNQUFNLENBQUM2QyxPQUFQLENBQWUsUUFBZixFQUF5QixZQUFXO0FBQ2xDLFNBQU8xRCxNQUFNLENBQUMyRCxJQUFQLENBQVksRUFBWixDQUFQO0FBQ0QsQ0FGRDtBQUlBOUMsTUFBTSxDQUFDNkMsT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVztBQUNuQyxTQUFPL0MsT0FBTyxDQUFDZ0QsSUFBUixDQUFhLEVBQWIsQ0FBUDtBQUNELENBRkQ7QUFJQTlDLE1BQU0sQ0FBQzZDLE9BQVAsQ0FBZSxjQUFmLEVBQStCLFVBQVNFLFdBQVQsRUFBc0I7QUFDbkQsUUFBTUMsWUFBWSxHQUFHbEQsT0FBTyxDQUFDZ0QsSUFBUixDQUFhO0FBQUNDLGVBQVcsRUFBRUUsUUFBUSxDQUFDRixXQUFEO0FBQXRCLEdBQWIsQ0FBckI7QUFDQSxRQUFNRyxNQUFNLEdBQUdGLFlBQVksQ0FBQ0csS0FBYixHQUFxQixDQUFyQixDQUFmO0FBQ0EsUUFBTUMsV0FBVyxHQUFHakUsTUFBTSxDQUFDMkQsSUFBUCxDQUFZO0FBQUUvQixPQUFHLEVBQUVtQyxNQUFNLENBQUNqQztBQUFkLEdBQVosQ0FBcEI7QUFDQSxTQUFPLENBQ0wrQixZQURLLEVBRUxJLFdBRkssQ0FBUDtBQUlELENBUkQ7QUFXQXBELE1BQU0sQ0FBQ3FELE9BQVAsQ0FBZSxNQUFNLENBRXBCLENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgSW1hZ2VzID0gbmV3IEZTLkNvbGxlY3Rpb24oXCJpbWFnZXNcIiwge1xuICBmaWx0ZXI6IHtcbiAgICBtYXhTaXplOiAyNjIxNDQwMCxcbiAgICBhbGxvdzoge1xuICAgICAgY29udGVudFR5cGVzOiBbJ2ltYWdlLyonXVxuICAgIH1cbiAgfSxcbiAgc3RvcmVzOiBbbmV3IEZTLlN0b3JlLkZpbGVTeXN0ZW0oXCJpbWFnZXNcIiwge3BhdGg6IFwifi91cGxvYWRzXCJ9KV1cbn0pOyIsImV4cG9ydCBkZWZhdWx0IFNjcmVlbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2NyZWVucycpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pbXBvcnQgaXAgZnJvbSAnaXAnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcblxuY29uc3QgYWRtaW5QYXNzd29yZCA9ICd2aXN1Y29uY2VwdCc7XG5jb25zdCB1c2VyUGFzc3dvcmRGaWxlUGF0aCA9ICcvaG9tZS92aXN1Y29uY2VwdC9wYXNzd29yZC50eHQnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdpcF9nZXQnOiAoKSA9PiB7XG4gICAgcmV0dXJuIGlwLmFkZHJlc3MoKTtcbiAgfSxcbiAgJ3NjcmVlbl91cGRhdGVJbWFnZSc6IChzY3JlZW5faWQsIGltYWdlX2lkLCBpbWFnZV91cmwpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnc2NyZWVuX3Jlc2V0Jywgc2NyZWVuX2lkKTtcbiAgICBTY3JlZW5zLnVwZGF0ZSh7IF9pZDogc2NyZWVuX2lkIH0sIHsgJHNldDogeyBpbWFnZUlkOiBpbWFnZV9pZCwgaW1hZ2VVcmw6IGltYWdlX3VybCwgZW5hYmxlZDogdHJ1ZSB9IH0pO1xuICB9LFxuICAnc2NyZWVuX3RvZ2dsZUVuYWJsZWQnOiAoc2NyZWVuX2lkLCBlbmFibGVkKSA9PiB7XG4gICAgU2NyZWVucy51cGRhdGUoe19pZDogc2NyZWVuX2lkfSwgeyAkc2V0OiB7IGVuYWJsZWQ6ICFlbmFibGVkIH0gfSk7XG4gIH0sXG4gICdzY3JlZW5fdXBkYXRlTmFtZSc6IChzY3JlZW5faWQsIG5hbWUpID0+IHtcbiAgICBTY3JlZW5zLnVwZGF0ZSh7X2lkOiBzY3JlZW5faWR9LCB7ICRzZXQ6IHsgbmFtZSB9IH0pXG4gIH0sXG4gICdzY3JlZW5fdG9nZ2xlRmlsbEFuZFN0cmV0Y2gnOiAoc2NyZWVuX2lkLCBmaWxsLCBzdHJldGNoKSA9PiB7XG4gICAgaWYoZmlsbCA9PT0gIXN0cmV0Y2gpIHtcbiAgICAgIFNjcmVlbnMudXBkYXRlKHsgX2lkOiBzY3JlZW5faWQgfSwgeyAkc2V0OiB7IGJhY2tncm91bmRTdHJldGNoOiAhc3RyZXRjaCwgZmlsbFNjcmVlbjogIWZpbGwgfSB9KTtcbiAgICB9XG4gIH0sXG4gICdzY3JlZW5fdXBkYXRlRmlsbCc6IChzY3JlZW5faWQsIGZpbGwsIHN0cmV0Y2gpID0+IHtcbiAgICBpZihzdHJldGNoKSB7XG4gICAgICBNZXRlb3IuY2FsbCgnc2NyZWVuX3RvZ2dsZUZpbGxBbmRTdHJldGNoJywgc2NyZWVuX2lkLCBmaWxsLCBzdHJldGNoKTtcbiAgICB9XG4gICAgU2NyZWVucy51cGRhdGUoeyBfaWQ6IHNjcmVlbl9pZCB9LCB7ICRzZXQ6IHsgZmlsbFNjcmVlbjogIWZpbGx9IH0pO1xuICB9LFxuICAnc2NyZWVuX3VwZGF0ZVN0cmV0Y2gnOiAoc2NyZWVuX2lkLCBmaWxsLCBzdHJldGNoKSA9PiB7XG4gICAgaWYoZmlsbCkge1xuICAgICAgTWV0ZW9yLmNhbGwoJ3NjcmVlbl90b2dnbGVGaWxsQW5kU3RyZXRjaCcsIHNjcmVlbl9pZCwgZmlsbCwgc3RyZXRjaCk7XG4gICAgfVxuICAgIFNjcmVlbnMudXBkYXRlKHsgX2lkOiBzY3JlZW5faWQgfSwgeyAkc2V0OiB7IGJhY2tncm91bmRTdHJldGNoOiAhc3RyZXRjaCB9IH0pO1xuICB9LFxuICAnc2NyZWVuX3VwZGF0ZVpvb20nOiAoc2NyZWVuX2lkLCB2YWx1ZSkgPT4ge1xuICAgIFNjcmVlbnMudXBkYXRlKHsgX2lkOiBzY3JlZW5faWQgfSwgeyAkc2V0OiB7IGJhY2tncm91bmRTaXplUGVyY2VudDogdmFsdWUgfSB9KTtcbiAgfSxcbiAgJ3NjcmVlbl91cGRhdGVIb3Jpem9udGFsUG9zaXRpb24nOiAoc2NyZWVuX2lkLCB2YWx1ZSwgdmVydGljYWxfdmFsdWUsIHJlc2V0KSA9PiB7XG4gICAgaWYocmVzZXQpIHtcbiAgICAgIHZhbHVlID0gNTA7IHZlcnRpY2FsX3ZhbHVlID0gNTA7XG4gICAgfVxuICAgIFNjcmVlbnMudXBkYXRlKHtfaWQ6IHNjcmVlbl9pZH0sIHsgJHNldDogeyBiYWNrZ3JvdW5kUG9zaXRpb25Ib3Jpem9udGFsOiB2YWx1ZSwgYmFja2dyb3VuZFBvc2l0aW9uOiBgJHsgdmFsdWUgfSUgJHsgdmVydGljYWxfdmFsdWUgfSVgIH0gfSk7XG4gIH0sXG4gICdzY3JlZW5fdXBkYXRlVmVydGljYWxQb3NpdGlvbic6IChzY3JlZW5faWQsIHZhbHVlLCBob3Jpem9udGFsX3ZhbHVlLCByZXNldCkgPT4ge1xuICAgIGlmKHJlc2V0KSB7XG4gICAgICB2YWx1ZSA9IDUwOyBob3Jpem9udGFsX3ZhbHVlID0gNTA7XG4gICAgfVxuICAgIFNjcmVlbnMudXBkYXRlKHtfaWQ6IHNjcmVlbl9pZH0sIHsgJHNldDogeyBiYWNrZ3JvdW5kUG9zaXRpb25WZXJ0aWNhbDogdmFsdWUsIGJhY2tncm91bmRQb3NpdGlvbjogYCR7IGhvcml6b250YWxfdmFsdWUgfSUgJHsgdmFsdWUgfSVgIH0gfSk7XG4gIH0sXG4gICdzY3JlZW5fcmVzZXQnOiAoc2NyZWVuX2lkKSA9PiB7XG4gICAgU2NyZWVucy51cGRhdGUoe19pZDogc2NyZWVuX2lkfSwgeyAkc2V0OiB7IGJhY2tncm91bmRQb3NpdGlvbjogJzUwJSA1MCUnLCBiYWNrZ3JvdW5kUG9zaXRpb25WZXJ0aWNhbDogNTAsIGJhY2tncm91bmRQb3NpdGlvbkhvcml6b250YWw6IDUwLCBiYWNrZ3JvdW5kU2l6ZVBlcmNlbnQ6IDEwMCwgYmFja2dyb3VuZFN0cmV0Y2g6IGZhbHNlLCBmaWxsU2NyZWVuOiBmYWxzZX0gfSk7XG4gIH0sXG4gICdpbWFnZV9yZW1vdmUnOiAoaW1hZ2VJZCwgaW1hZ2VVcmwpID0+IHtcbiAgICBTY3JlZW5zLnVwZGF0ZSh7aW1hZ2VVcmw6IGltYWdlVXJsfSwgeyAkc2V0OiB7XG4gICAgICBpbWFnZVVybDogbnVsbCxcbiAgICAgIGVuYWJsZWQ6IGZhbHNlLFxuICAgICAgYmFja2dyb3VuZFNpemVQZXJjZW50OiAxMDAsXG4gICAgICBiYWNrZ3JvdW5kUG9zaXRpb25Ib3Jpem9udGFsOiA1MCxcbiAgICAgIGJhY2tncm91bmRQb3NpdGlvblZlcnRpY2FsOiA1MCxcbiAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJzUwJSA1MCUnLFxuICAgICAgYmFja2dyb3VuZFN0cmV0Y2g6IGZhbHNlLFxuICAgICAgZmlsbFNjcmVlbjogZmFsc2UsXG4gICAgICBiYWNrZ3JvdW5kU2l6ZTogJ2NvbnRhaW4nfSB9LFxuICAgICAgeyBtdWx0aTogdHJ1ZSB9XG4gICAgKTtcbiAgICBJbWFnZXMucmVtb3ZlKHtfaWQ6IGltYWdlSWR9KTtcbiAgfSxcbiAgJ2NoZWNrX3Bhc3N3b3JkJzogKHBhc3N3b3JkKSA9PiB7XG4gICAgY29uc3QgdXNlclBhc3N3b3JkID0gZnMucmVhZEZpbGVTeW5jKHVzZXJQYXNzd29yZEZpbGVQYXRoLCB7IGVuY29kaW5nOiAndXRmOCcgfSk7XG4gICAgaWYocGFzc3dvcmQgPT09IGFkbWluUGFzc3dvcmQgfHwgcGFzc3dvcmQgPT09IHVzZXJQYXNzd29yZCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH0sXG4gICdjaGFuZ2VfcGFzc3dvcmQnOiAob2xkUGFzc3dvcmQsIG5ld1Bhc3N3b3JkKSA9PiB7XG4gICAgY29uc3QgdXNlclBhc3N3b3JkID0gZnMucmVhZEZpbGVTeW5jKHVzZXJQYXNzd29yZEZpbGVQYXRoLCB7IGVuY29kaW5nOiAndXRmOCcgfSk7XG4gICAgaWYob2xkUGFzc3dvcmQgPT09IGFkbWluUGFzc3dvcmQgfHwgb2xkUGFzc3dvcmQgPT09IHVzZXJQYXNzd29yZCkge1xuICAgICAgZnMud3JpdGVGaWxlU3luYyh1c2VyUGFzc3dvcmRGaWxlUGF0aCwgbmV3UGFzc3dvcmQsICd1dGY4Jyk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0IEltYWdlcyBmcm9tICcuLi9pbXBvcnRzL2FwaS9pbWFnZXMnO1xuaW1wb3J0IFNjcmVlbnMgZnJvbSAnLi4vaW1wb3J0cy9hcGkvc2NyZWVucyc7XG5cbmltcG9ydCAnLi4vaW1wb3J0cy9zaGFyZWQvbWV0aG9kcyc7XG5cbkltYWdlcy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxuICBkb3dubG9hZDogKCkgPT4gdHJ1ZVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdpbWFnZXMnLCBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIEltYWdlcy5maW5kKHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnc2NyZWVucycsIGZ1bmN0aW9uKCkge1xuICByZXR1cm4gU2NyZWVucy5maW5kKHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnc2NyZWVuX2ltYWdlJywgZnVuY3Rpb24oc2NyZWVuSW5kZXgpIHtcbiAgY29uc3Qgc2NyZWVuQ3Vyc29yID0gU2NyZWVucy5maW5kKHtzY3JlZW5JbmRleDogcGFyc2VJbnQoc2NyZWVuSW5kZXgpfSk7XG4gIGNvbnN0IHNjcmVlbiA9IHNjcmVlbkN1cnNvci5mZXRjaCgpWzBdO1xuICBjb25zdCBpbWFnZUN1cnNvciA9IEltYWdlcy5maW5kKHsgX2lkOiBzY3JlZW4uaW1hZ2VJZCB9KVxuICByZXR1cm4gW1xuICAgIHNjcmVlbkN1cnNvcixcbiAgICBpbWFnZUN1cnNvclxuICBdO1xufSk7XG5cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuXG59KTtcblxuXG5cbiJdfQ==
