var require = meteorInstall({"imports":{"api":{"images.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/images.js                                                 //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.exportDefault(Images = new FS.Collection("images", {
  filter: {
    maxSize: 26214400,
    allow: {
      contentTypes: ['image/*']
    }
  },
  stores: [new FS.Store.FileSystem("images", {
    path: "~/uploads"
  })]
}));
///////////////////////////////////////////////////////////////////////////

},"screens.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/screens.js                                                //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.exportDefault(Screens = new Mongo.Collection('screens'));
///////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// server/main.js                                                        //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let dgram;
module.link("dgram", {
  default(v) {
    dgram = v;
  }

}, 1);
let ip;
module.link("ip", {
  default(v) {
    ip = v;
  }

}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 3);
let Images;
module.link("../imports/api/images", {
  default(v) {
    Images = v;
  }

}, 4);
let Screens;
module.link("../imports/api/screens", {
  default(v) {
    Screens = v;
  }

}, 5);
const adminPassword = '12345';
const userPasswordFilePath = '/home/visuconcept/password.txt';
Meteor.publish('images', function () {
  return Images.find({});
});
Meteor.publish('screens', function () {
  return Screens.find({});
});
Meteor.publish('screen_image', function (screenIndex) {
  const screenCursor = Screens.find({
    screenIndex: parseInt(screenIndex)
  });
  const screen = screenCursor.fetch()[0];
  const imageCursor = Images.find({
    _id: screen.imageId
  });
  return [screenCursor, imageCursor];
});
Meteor.startup(() => {// const UDP_PORT = 5769;
  // const ID = 'adscreens_server';
  // const server = dgram.createSocket('udp4');
  // server.on('listening', () => {
  //   console.log('le serveur est à l\'écoute');
  // })
  // server.on('message', (buffer) => {
  //   const res = JSON.parse(buffer.toString());
  //   if(res.id && res.ip) {
  //     if(res.id === 'adscreens_client') {console.log(res);
  //       const req = {
  //         id: ID,
  //         ip: ip.address()
  //       }
  //       const buffer = Buffer.from(JSON.stringify(req));
  //       server.send(buffer, 5768, '127.0.0.1', (err) => {
  //         console.log('Erreur: ', err);
  //       });
  //     }
  //   }
  // })
  // server.bind(UDP_PORT, () => {
  //   server.setBroadcast(true);
  // });
});
Meteor.methods({
  'image_remove': (imageId, imageUrl) => {
    Screens.update({
      imageUrl: imageUrl
    }, {
      $set: {
        imageUrl: null,
        enabled: false,
        backgroundSizePercent: 100,
        backgroundPositionHorizontal: 50,
        backgroundPositionVertical: 50,
        backgroundPosition: '50% 50%',
        backgroundStretch: false,
        fillScreen: false,
        backgroundSize: 'contain'
      }
    }, {
      multi: true
    });
    Images.remove({
      _id: imageId
    });
  },
  'check_password': password => {
    const userPassword = fs.readFileSync(userPasswordFilePath, {
      encoding: 'utf8'
    });

    if (password === adminPassword || password === userPassword) {
      return true;
    } else {
      return false;
    }
  },
  'change_password': (oldPassword, newPassword) => {
    const userPassword = fs.readFileSync(userPasswordFilePath, {
      encoding: 'utf8'
    });

    if (oldPassword === adminPassword || oldPassword === userPassword) {
      fs.writeFileSync(userPasswordFilePath, newPassword, 'utf8');
      return true;
    }

    return false;
  }
});
///////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW1hZ2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zY3JlZW5zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnREZWZhdWx0IiwiSW1hZ2VzIiwiRlMiLCJDb2xsZWN0aW9uIiwiZmlsdGVyIiwibWF4U2l6ZSIsImFsbG93IiwiY29udGVudFR5cGVzIiwic3RvcmVzIiwiU3RvcmUiLCJGaWxlU3lzdGVtIiwicGF0aCIsIlNjcmVlbnMiLCJNb25nbyIsIk1ldGVvciIsImxpbmsiLCJ2IiwiZGdyYW0iLCJkZWZhdWx0IiwiaXAiLCJmcyIsImFkbWluUGFzc3dvcmQiLCJ1c2VyUGFzc3dvcmRGaWxlUGF0aCIsInB1Ymxpc2giLCJmaW5kIiwic2NyZWVuSW5kZXgiLCJzY3JlZW5DdXJzb3IiLCJwYXJzZUludCIsInNjcmVlbiIsImZldGNoIiwiaW1hZ2VDdXJzb3IiLCJfaWQiLCJpbWFnZUlkIiwic3RhcnR1cCIsIm1ldGhvZHMiLCJpbWFnZVVybCIsInVwZGF0ZSIsIiRzZXQiLCJlbmFibGVkIiwiYmFja2dyb3VuZFNpemVQZXJjZW50IiwiYmFja2dyb3VuZFBvc2l0aW9uSG9yaXpvbnRhbCIsImJhY2tncm91bmRQb3NpdGlvblZlcnRpY2FsIiwiYmFja2dyb3VuZFBvc2l0aW9uIiwiYmFja2dyb3VuZFN0cmV0Y2giLCJmaWxsU2NyZWVuIiwiYmFja2dyb3VuZFNpemUiLCJtdWx0aSIsInJlbW92ZSIsInBhc3N3b3JkIiwidXNlclBhc3N3b3JkIiwicmVhZEZpbGVTeW5jIiwiZW5jb2RpbmciLCJvbGRQYXNzd29yZCIsIm5ld1Bhc3N3b3JkIiwid3JpdGVGaWxlU3luYyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxhQUFQLENBQWVDLE1BQU0sR0FBRyxJQUFJQyxFQUFFLENBQUNDLFVBQVAsQ0FBa0IsUUFBbEIsRUFBNEI7QUFDbERDLFFBQU0sRUFBRTtBQUNOQyxXQUFPLEVBQUUsUUFESDtBQUVOQyxTQUFLLEVBQUU7QUFDTEMsa0JBQVksRUFBRSxDQUFDLFNBQUQ7QUFEVDtBQUZELEdBRDBDO0FBT2xEQyxRQUFNLEVBQUUsQ0FBQyxJQUFJTixFQUFFLENBQUNPLEtBQUgsQ0FBU0MsVUFBYixDQUF3QixRQUF4QixFQUFrQztBQUFDQyxRQUFJLEVBQUU7QUFBUCxHQUFsQyxDQUFEO0FBUDBDLENBQTVCLENBQXhCLEU7Ozs7Ozs7Ozs7O0FDQUFaLE1BQU0sQ0FBQ0MsYUFBUCxDQUFlWSxPQUFPLEdBQUcsSUFBSUMsS0FBSyxDQUFDVixVQUFWLENBQXFCLFNBQXJCLENBQXpCLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSVcsTUFBSjtBQUFXZixNQUFNLENBQUNnQixJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVbEIsTUFBTSxDQUFDZ0IsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBQTZDLElBQUlHLEVBQUo7QUFBT3BCLE1BQU0sQ0FBQ2dCLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNHLE1BQUUsR0FBQ0gsQ0FBSDtBQUFLOztBQUFqQixDQUFqQixFQUFvQyxDQUFwQztBQUF1QyxJQUFJSSxFQUFKO0FBQU9yQixNQUFNLENBQUNnQixJQUFQLENBQVksSUFBWixFQUFpQjtBQUFDRyxTQUFPLENBQUNGLENBQUQsRUFBRztBQUFDSSxNQUFFLEdBQUNKLENBQUg7QUFBSzs7QUFBakIsQ0FBakIsRUFBb0MsQ0FBcEM7QUFBdUMsSUFBSWYsTUFBSjtBQUFXRixNQUFNLENBQUNnQixJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ0csU0FBTyxDQUFDRixDQUFELEVBQUc7QUFBQ2YsVUFBTSxHQUFDZSxDQUFQO0FBQVM7O0FBQXJCLENBQXBDLEVBQTJELENBQTNEO0FBQThELElBQUlKLE9BQUo7QUFBWWIsTUFBTSxDQUFDZ0IsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNHLFNBQU8sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNKLFdBQU8sR0FBQ0ksQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RDtBQVF4UyxNQUFNSyxhQUFhLEdBQUcsT0FBdEI7QUFDQSxNQUFNQyxvQkFBb0IsR0FBRyxnQ0FBN0I7QUFHQVIsTUFBTSxDQUFDUyxPQUFQLENBQWUsUUFBZixFQUF5QixZQUFXO0FBQ2xDLFNBQU90QixNQUFNLENBQUN1QixJQUFQLENBQVksRUFBWixDQUFQO0FBQ0QsQ0FGRDtBQUlBVixNQUFNLENBQUNTLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVc7QUFDbkMsU0FBT1gsT0FBTyxDQUFDWSxJQUFSLENBQWEsRUFBYixDQUFQO0FBQ0QsQ0FGRDtBQUlBVixNQUFNLENBQUNTLE9BQVAsQ0FBZSxjQUFmLEVBQStCLFVBQVNFLFdBQVQsRUFBc0I7QUFDbkQsUUFBTUMsWUFBWSxHQUFHZCxPQUFPLENBQUNZLElBQVIsQ0FBYTtBQUFDQyxlQUFXLEVBQUVFLFFBQVEsQ0FBQ0YsV0FBRDtBQUF0QixHQUFiLENBQXJCO0FBQ0EsUUFBTUcsTUFBTSxHQUFHRixZQUFZLENBQUNHLEtBQWIsR0FBcUIsQ0FBckIsQ0FBZjtBQUNBLFFBQU1DLFdBQVcsR0FBRzdCLE1BQU0sQ0FBQ3VCLElBQVAsQ0FBWTtBQUFFTyxPQUFHLEVBQUVILE1BQU0sQ0FBQ0k7QUFBZCxHQUFaLENBQXBCO0FBQ0EsU0FBTyxDQUNMTixZQURLLEVBRUxJLFdBRkssQ0FBUDtBQUlELENBUkQ7QUFXQWhCLE1BQU0sQ0FBQ21CLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNELENBakNEO0FBb0NBbkIsTUFBTSxDQUFDb0IsT0FBUCxDQUFlO0FBQ2Isa0JBQWdCLENBQUNGLE9BQUQsRUFBVUcsUUFBVixLQUF1QjtBQUNyQ3ZCLFdBQU8sQ0FBQ3dCLE1BQVIsQ0FBZTtBQUFDRCxjQUFRLEVBQUVBO0FBQVgsS0FBZixFQUFxQztBQUFFRSxVQUFJLEVBQUU7QUFDM0NGLGdCQUFRLEVBQUUsSUFEaUM7QUFFM0NHLGVBQU8sRUFBRSxLQUZrQztBQUczQ0MsNkJBQXFCLEVBQUUsR0FIb0I7QUFJM0NDLG9DQUE0QixFQUFFLEVBSmE7QUFLM0NDLGtDQUEwQixFQUFFLEVBTGU7QUFNM0NDLDBCQUFrQixFQUFFLFNBTnVCO0FBTzNDQyx5QkFBaUIsRUFBRSxLQVB3QjtBQVEzQ0Msa0JBQVUsRUFBRSxLQVIrQjtBQVMzQ0Msc0JBQWMsRUFBRTtBQVQyQjtBQUFSLEtBQXJDLEVBVUU7QUFBRUMsV0FBSyxFQUFFO0FBQVQsS0FWRjtBQVlBN0MsVUFBTSxDQUFDOEMsTUFBUCxDQUFjO0FBQUNoQixTQUFHLEVBQUVDO0FBQU4sS0FBZDtBQUNELEdBZlk7QUFnQmIsb0JBQW1CZ0IsUUFBRCxJQUFjO0FBQzlCLFVBQU1DLFlBQVksR0FBRzdCLEVBQUUsQ0FBQzhCLFlBQUgsQ0FBZ0I1QixvQkFBaEIsRUFBc0M7QUFBRTZCLGNBQVEsRUFBRTtBQUFaLEtBQXRDLENBQXJCOztBQUNBLFFBQUdILFFBQVEsS0FBSzNCLGFBQWIsSUFBOEIyQixRQUFRLEtBQUtDLFlBQTlDLEVBQTREO0FBQzFELGFBQU8sSUFBUDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sS0FBUDtBQUNEO0FBQ0YsR0F2Qlk7QUF3QmIscUJBQW1CLENBQUNHLFdBQUQsRUFBY0MsV0FBZCxLQUE4QjtBQUMvQyxVQUFNSixZQUFZLEdBQUc3QixFQUFFLENBQUM4QixZQUFILENBQWdCNUIsb0JBQWhCLEVBQXNDO0FBQUU2QixjQUFRLEVBQUU7QUFBWixLQUF0QyxDQUFyQjs7QUFDQSxRQUFHQyxXQUFXLEtBQUsvQixhQUFoQixJQUFpQytCLFdBQVcsS0FBS0gsWUFBcEQsRUFBa0U7QUFDaEU3QixRQUFFLENBQUNrQyxhQUFILENBQWlCaEMsb0JBQWpCLEVBQXVDK0IsV0FBdkMsRUFBb0QsTUFBcEQ7QUFDQSxhQUFPLElBQVA7QUFDRDs7QUFDRCxXQUFPLEtBQVA7QUFDRDtBQS9CWSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IEltYWdlcyA9IG5ldyBGUy5Db2xsZWN0aW9uKFwiaW1hZ2VzXCIsIHtcbiAgZmlsdGVyOiB7XG4gICAgbWF4U2l6ZTogMjYyMTQ0MDAsXG4gICAgYWxsb3c6IHtcbiAgICAgIGNvbnRlbnRUeXBlczogWydpbWFnZS8qJ11cbiAgICB9XG4gIH0sXG4gIHN0b3JlczogW25ldyBGUy5TdG9yZS5GaWxlU3lzdGVtKFwiaW1hZ2VzXCIsIHtwYXRoOiBcIn4vdXBsb2Fkc1wifSldXG59KTsiLCJleHBvcnQgZGVmYXVsdCBTY3JlZW5zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NjcmVlbnMnKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSc7XG5pbXBvcnQgaXAgZnJvbSAnaXAnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcblxuaW1wb3J0IEltYWdlcyBmcm9tICcuLi9pbXBvcnRzL2FwaS9pbWFnZXMnO1xuaW1wb3J0IFNjcmVlbnMgZnJvbSAnLi4vaW1wb3J0cy9hcGkvc2NyZWVucyc7XG5cbmNvbnN0IGFkbWluUGFzc3dvcmQgPSAnMTIzNDUnO1xuY29uc3QgdXNlclBhc3N3b3JkRmlsZVBhdGggPSAnL2hvbWUvdmlzdWNvbmNlcHQvcGFzc3dvcmQudHh0JztcblxuXG5NZXRlb3IucHVibGlzaCgnaW1hZ2VzJywgZnVuY3Rpb24oKSB7XG4gIHJldHVybiBJbWFnZXMuZmluZCh7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3NjcmVlbnMnLCBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIFNjcmVlbnMuZmluZCh7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3NjcmVlbl9pbWFnZScsIGZ1bmN0aW9uKHNjcmVlbkluZGV4KSB7XG4gIGNvbnN0IHNjcmVlbkN1cnNvciA9IFNjcmVlbnMuZmluZCh7c2NyZWVuSW5kZXg6IHBhcnNlSW50KHNjcmVlbkluZGV4KX0pO1xuICBjb25zdCBzY3JlZW4gPSBzY3JlZW5DdXJzb3IuZmV0Y2goKVswXTtcbiAgY29uc3QgaW1hZ2VDdXJzb3IgPSBJbWFnZXMuZmluZCh7IF9pZDogc2NyZWVuLmltYWdlSWQgfSlcbiAgcmV0dXJuIFtcbiAgICBzY3JlZW5DdXJzb3IsXG4gICAgaW1hZ2VDdXJzb3JcbiAgXTtcbn0pO1xuXG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgLy8gY29uc3QgVURQX1BPUlQgPSA1NzY5O1xuICAvLyBjb25zdCBJRCA9ICdhZHNjcmVlbnNfc2VydmVyJztcbiAgXG4gIC8vIGNvbnN0IHNlcnZlciA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpO1xuICBcbiAgLy8gc2VydmVyLm9uKCdsaXN0ZW5pbmcnLCAoKSA9PiB7XG4gIC8vICAgY29uc29sZS5sb2coJ2xlIHNlcnZldXIgZXN0IMOgIGxcXCfDqWNvdXRlJyk7XG4gIC8vIH0pXG4gIFxuICAvLyBzZXJ2ZXIub24oJ21lc3NhZ2UnLCAoYnVmZmVyKSA9PiB7XG4gIC8vICAgY29uc3QgcmVzID0gSlNPTi5wYXJzZShidWZmZXIudG9TdHJpbmcoKSk7XG4gIFxuICAvLyAgIGlmKHJlcy5pZCAmJiByZXMuaXApIHtcbiAgLy8gICAgIGlmKHJlcy5pZCA9PT0gJ2Fkc2NyZWVuc19jbGllbnQnKSB7Y29uc29sZS5sb2cocmVzKTtcbiAgXG4gIC8vICAgICAgIGNvbnN0IHJlcSA9IHtcbiAgLy8gICAgICAgICBpZDogSUQsXG4gIC8vICAgICAgICAgaXA6IGlwLmFkZHJlc3MoKVxuICAvLyAgICAgICB9XG4gIFxuICAvLyAgICAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShKU09OLnN0cmluZ2lmeShyZXEpKTtcbiAgXG4gIC8vICAgICAgIHNlcnZlci5zZW5kKGJ1ZmZlciwgNTc2OCwgJzEyNy4wLjAuMScsIChlcnIpID0+IHtcbiAgLy8gICAgICAgICBjb25zb2xlLmxvZygnRXJyZXVyOiAnLCBlcnIpO1xuICAvLyAgICAgICB9KTtcbiAgLy8gICAgIH1cbiAgLy8gICB9XG4gIC8vIH0pXG4gIFxuICAvLyBzZXJ2ZXIuYmluZChVRFBfUE9SVCwgKCkgPT4ge1xuICAvLyAgIHNlcnZlci5zZXRCcm9hZGNhc3QodHJ1ZSk7XG4gIC8vIH0pO1xufSk7XG5cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnaW1hZ2VfcmVtb3ZlJzogKGltYWdlSWQsIGltYWdlVXJsKSA9PiB7XG4gICAgU2NyZWVucy51cGRhdGUoe2ltYWdlVXJsOiBpbWFnZVVybH0sIHsgJHNldDoge1xuICAgICAgaW1hZ2VVcmw6IG51bGwsXG4gICAgICBlbmFibGVkOiBmYWxzZSxcbiAgICAgIGJhY2tncm91bmRTaXplUGVyY2VudDogMTAwLFxuICAgICAgYmFja2dyb3VuZFBvc2l0aW9uSG9yaXpvbnRhbDogNTAsXG4gICAgICBiYWNrZ3JvdW5kUG9zaXRpb25WZXJ0aWNhbDogNTAsXG4gICAgICBiYWNrZ3JvdW5kUG9zaXRpb246ICc1MCUgNTAlJyxcbiAgICAgIGJhY2tncm91bmRTdHJldGNoOiBmYWxzZSxcbiAgICAgIGZpbGxTY3JlZW46IGZhbHNlLFxuICAgICAgYmFja2dyb3VuZFNpemU6ICdjb250YWluJ30gfSxcbiAgICAgIHsgbXVsdGk6IHRydWUgfVxuICAgICk7XG4gICAgSW1hZ2VzLnJlbW92ZSh7X2lkOiBpbWFnZUlkfSk7XG4gIH0sXG4gICdjaGVja19wYXNzd29yZCc6IChwYXNzd29yZCkgPT4ge1xuICAgIGNvbnN0IHVzZXJQYXNzd29yZCA9IGZzLnJlYWRGaWxlU3luYyh1c2VyUGFzc3dvcmRGaWxlUGF0aCwgeyBlbmNvZGluZzogJ3V0ZjgnIH0pO1xuICAgIGlmKHBhc3N3b3JkID09PSBhZG1pblBhc3N3b3JkIHx8IHBhc3N3b3JkID09PSB1c2VyUGFzc3dvcmQpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9LFxuICAnY2hhbmdlX3Bhc3N3b3JkJzogKG9sZFBhc3N3b3JkLCBuZXdQYXNzd29yZCkgPT4ge1xuICAgIGNvbnN0IHVzZXJQYXNzd29yZCA9IGZzLnJlYWRGaWxlU3luYyh1c2VyUGFzc3dvcmRGaWxlUGF0aCwgeyBlbmNvZGluZzogJ3V0ZjgnIH0pO1xuICAgIGlmKG9sZFBhc3N3b3JkID09PSBhZG1pblBhc3N3b3JkIHx8IG9sZFBhc3N3b3JkID09PSB1c2VyUGFzc3dvcmQpIHtcbiAgICAgIGZzLndyaXRlRmlsZVN5bmModXNlclBhc3N3b3JkRmlsZVBhdGgsIG5ld1Bhc3N3b3JkLCAndXRmOCcpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufSk7XG5cbiJdfQ==
